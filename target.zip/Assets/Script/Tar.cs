﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tar : MonoBehaviour
{
    public bool ishit;
    public GameObject m;

    private void Awake() {
        ishit = true;
        m = GameObject.Find("GameManager");
        this.transform.rotation = Quaternion.Euler(new Vector3(90, 0, 0));
        
    }
    
    void FixedUpdate() { 
    
        if (this.transform.rotation.x > 0.01f && ishit == false)
            this.transform.Rotate(new Vector3(-270 * Time.deltaTime, 0, 0));

        if (ishit == true) {

            if (this.transform.rotation.x < Quaternion.Euler(new Vector3(90, 0, 0)).x) {
                this.transform.Rotate(new Vector3(2000f * Time.deltaTime, 0, 0));
            }

            if (this.transform.rotation.x > Quaternion.Euler(new Vector3(90, 0, 0)).x) {
                //m.SendMessage("Recru");
            }
        }
    }
}
