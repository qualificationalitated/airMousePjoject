﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Manager : MonoBehaviour {
    public static int score;
    private Vector3 vec;
    Ray ray;
    RaycastHit hit;
    static GameObject obj;
    public GameObject newObj;
    public GameObject cursor;
    int i;


    void Awake() {
        
        Cursor.visible = false;
        score = 0;
        i = Random.Range(1, 26);
        newObj = GameObject.Find("Target (" + i + ")");
        newObj.GetComponent<Tar>().ishit = false;
        Debug.Log(newObj.GetComponent<Tar>().ishit);
    }

    
    void FixedUpdate() {
        Firing();

        vec = new Vector2(Input.mousePosition.x / 1920 * 14.38f - 7.19f, Input.mousePosition.y / 1080 * 8.08f + 0.96f);
        cursor.transform.position = new Vector3(vec.x, vec.y, -33);

        //Debug.Log(Input.mousePosition);

        Recru();

        //newObj.SetActive(true);

    }

    void Firing() {
        if (Input.GetMouseButtonDown(0)) {
           

            ray = Camera.main.ScreenPointToRay(Input.mousePosition);

            if (Physics.Raycast(ray, out hit, 100f) && (hit.collider.tag == "head" || hit.collider.tag == "body")) {

                if (hit.collider.tag == "head") score += 120;
                else if (hit.collider.tag == "body") score += 100;


                //Debug.Log(hit.transform.gameObject.transform.parent.gameObject.name);
                obj = GameObject.Find(hit.transform.gameObject.transform.parent.gameObject.name);
                obj.GetComponent<Tar>().ishit = true;
               
            }
        }
    }

    void Recru() {
        int temp = 0;

        if (newObj.GetComponent<Tar>().ishit == true || newObj == null) {
            Debug.Log(score);
            
            do {
                temp = Random.Range(1, 26);
                //Debug.Log(temp);
            } while (temp == i);

            i = temp;

            newObj = GameObject.Find("Target (" + i + ")");
            newObj.GetComponent<Tar>().ishit = false;
            
        }
    }
}
